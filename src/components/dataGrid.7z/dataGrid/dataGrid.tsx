/*
Copyright 2024 TOTVS S.A

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http: //www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

import "./dataGrid.css";
import React from "react";
import {
	VSCodeButton, VSCodeDataGrid, VSCodeDataGridCell, VSCodeDataGridRow,
	VSCodeTextField, VSCodeDropdown, VSCodeOption,
	VSCodeLink,
	VSCodeCheckbox,
	VSCodeDivider,
	VSCodeBadge
} from "@vscode/webview-ui-toolkit/react";
import { UseFormReturn, useFormContext } from "react-hook-form";
import { TGroupingInfo, TTdsDataGridAction, TTdsDataGridColumnDef, TTdsDataGridProps } from "./dataGrid.type";
import { tdsVscode } from "../../utilities/vscodeWrapper";
import { TdsTextField } from "../fields/textField";
import TdsPaginator from "./paginator";
import { dataGridState, prepareDataSource, TDataGridState } from './dataGridState';
import { BuildRowFilter, FilterBlock } from "./fieldFilter";
import { DataSourceProvider, useDataSourceContext } from "./dataSourceContext";

/**
 * Renders the data grid component.
 *
 * @param props - The data grid component props.
 */
type TFieldDataProps = {
	fieldDef: TTdsDataGridColumnDef;
	row: any;
	fieldName?: string;
}

type TBuildRowsProps = {
	id: string;  //ID Datagrid 
	columnsDef: TTdsDataGridColumnDef[];
	//rows: any[];
	rowSeparator: boolean;
	itemOffset: number;
}

function BuildRows(props: TBuildRowsProps) {
	const { dataSource, itemOffset } = useDataSourceContext();

	const buildRow = (row: any, index: number, itemOffset: number): React.ReactElement[] => {
		let reactElements: React.ReactElement[] = [];
		let rowNumber: number = 0;

		while (rowNumber != -1) {
			let gridTemplate: string = "";

			props.columnsDef
				.filter(column => column.visible)
				.filter((column) => (column.rowGroup || 0) == rowNumber)
				.map((column, _index: number) => {
					gridTemplate += ` ${column.width || "1fr"} `;
				});

			reactElements.push(
				<VSCodeDataGridRow row-type="default"
					id={`${props.id}_row_${rowNumber}_${index + itemOffset}`}
					key={`${props.id}_row_${rowNumber}_${index + itemOffset}`}
					gridTemplateColumns={gridTemplate}
				>
					{props.columnsDef.filter(column => column.visible)
						.filter(column => (column.rowGroup || 0) == rowNumber)
						.map((column, indexCol: number) => (
							<VSCodeDataGridCell
								id={`${props.id}_cell_${rowNumber}_${index + itemOffset}${indexCol + 1}`}
								key={`${props.id}_cell__${rowNumber}_${index + itemOffset}${indexCol + 1}`}
								grid-column={indexCol + 1}>
								{fieldData(
									{
										fieldDef: column,
										row: row,
										fieldName: `${props.id}.${index + itemOffset}.${column.name}`
									})
								}
							</VSCodeDataGridCell>
						))}
				</VSCodeDataGridRow>
			);

			rowNumber = rowNumber + 1;

			if (props.columnsDef.findIndex(column => (column.rowGroup || 0) == rowNumber) == -1) {
				rowNumber = -1;
			}
		}

		if (props.rowSeparator) {
			reactElements.push(
				<VSCodeDataGridRow row-type="default" key={`${props.id}_row_separator_${index + itemOffset}`}>
					{props.columnsDef.filter(column => column.visible)
						.filter(column => (column.rowGroup || 0) == 0)
						.map((_column, indexCol: number) => (
							<VSCodeDataGridCell
								key={`${props.id}_cell_separator_${index + itemOffset}${indexCol + 1}`}
								grid-column={indexCol + 1}
								cell-type="rowseparator"
							>
								<VSCodeDivider role="separator"></VSCodeDivider>
							</VSCodeDataGridCell>
						))}
				</VSCodeDataGridRow>
			);
		}

		return reactElements;
	}

	return dataSource
		.slice(itemOffset, itemOffset + 10)
		.map((row: any, index: number) => buildRow(row, index, props.itemOffset))
}

function fieldData(props: TFieldDataProps) { //, forceRefresh: number = -1
	const methods = useFormContext();
	const column = props.fieldDef;
	const row = props.row;
	let alignClass: string | undefined = column.align ? `tds-text-${column.align}` : undefined;

	if (!row) {
		console.log("noRow");
	}

	//Campo DATE, TIME e DATETIME
	if ((column.type == "date") || (column.type == "time") || (column.type == "datetime")) {
		const text: string = tdsVscode.l10n.format(row[column.name], (column.displayType || column.type) as "date" | "time" | "datetime");
		alignClass = alignClass || "tds-text-right";
		return (
			<VSCodeTextField
				className={alignClass}
				data-type={column.type}
				key={`${props.fieldName}}`}
				readOnly={column.readOnly == undefined ? true : column.readOnly}
				value={text}
				title={text.startsWith("Invalid") ? row[column.name] : text}
			></VSCodeTextField>
		)
	}

	//Campo BOOLEAN
	if (column.type == "boolean") {
		alignClass = alignClass || "tds-text-center";

		return (
			<VSCodeCheckbox
				className={alignClass}
				key={`${props.fieldName}`}
				readOnly={column.readOnly == undefined ? true : column.readOnly}
				checked={methods.getValues(props.fieldName) || false}
				onChange={(e) => {
					e.preventDefault();
					e.stopPropagation();
					const target = e.target as HTMLInputElement;

					methods.setValue(props.fieldName, target.checked ? true : false);
					if (column.onChange) {
						column.onChange(e, props.fieldName, row);
					}
					return target.checked;
				}
				}
			></VSCodeCheckbox>
		)

	}

	const text: string = (column.lookup && column.lookup[row[column.name]])
		? column.lookup[row[column.name]]
		: tdsVscode.l10n.format(row[column.name], (column.displayType || column.type));

	if ((column.type == "number")) {
		alignClass = alignClass || "tds-text-right";
	}

	return (
		<VSCodeTextField
			className={alignClass}
			title={text}
			data-type={column.type}
			key={`${props.fieldName}`}
			readOnly={column.readOnly == undefined ? true : column.readOnly}
			value={(text || "<error>").startsWith("Invalid") ? row[column.name] || "<error>" : text}
		></VSCodeTextField>
	)
}

type TGroupingBlockProps = {
	groupingInfo: TGroupingInfo;
	onFilterValues: (Filter: string[] | undefined) => void;
}

function GroupingBlock(props: TGroupingBlockProps) {
	const groupingCol: TTdsDataGridColumnDef = props.groupingInfo.groupingCol;
	const groupingFilter = props.groupingInfo.groupingFilter;
	const groupingValues: Record<string, number> = props.groupingInfo.groupingValues;
	const values = Object.keys(groupingValues).sort((v1: string, v2: string) => v1.localeCompare(v2));

	return (
		<section className="tds-row-container">
			<div className="tds-data-grid-grouping">
				{
					//<span className="label">{tdsVscode.l10n.t("_Group by:")}</span>
				}
				<span className="field_name">{groupingCol.label || groupingCol.name}: </span>
				{values.map((data: string, index: number) => (
					<VSCodeButton
						key={`btn_grouping_filter_${groupingCol.name}.${index}`}
						appearance={groupingFilter.indexOf(data) > -1 ? "primary" : "secondary"}
						onClick={() => {
							let filter: string[] = groupingFilter;
							let pos: number = groupingFilter.indexOf(data);

							if (pos > -1) {
								delete filter[pos];
							} else {
								filter.push(data);
							}

							props.onFilterValues(filter);
						}}
					>
						{groupingCol.lookup && groupingCol.lookup[data]
							? groupingCol.lookup[data] : data}
						<VSCodeBadge>{groupingValues[data]}</VSCodeBadge>
					</VSCodeButton>
				))
				}
				<VSCodeButton appearance="icon" aria-label="Ungroup"
					key={`btn_grouping_${groupingCol.name}`}
					onClick={() => {
						props.onFilterValues(undefined);
					}}
				>
					<span className="codicon codicon-close"></span>
				</VSCodeButton>

			</div>
		</section>
	)
}

/**
 * Renders a data grid component with features like pagination, sorting, filtering, and grouping.
 *
 * @param props - The props for the data grid component.
 * @param props.id - The unique identifier for the data grid.
 * @param props.dataSource - The data source for the data grid.
 * @param props.columnDef - The column definitions for the data grid.
 * @param props.options - The options for the data grid, including pagination, filtering, and grouping settings.
 * @returns A React element representing the data grid.
 */
export function TdsDataGrid(props: TTdsDataGridProps): React.ReactElement {
	const x = 10;
	console.log(x);

	return (<DataSourceProvider>
		<TdsDataGrid2 {...props} />
	</DataSourceProvider>
	)
}

function TdsDataGrid2(props: TTdsDataGridProps): React.ReactElement {
	const [keyContent, setKeyContent] = React.useState(0);
	//const [dataSource, setDataSource] = React.useState([]);
	const {
		dataSource, setDataSource,
		filter,
		sortedColumn, setSortedColumn,
		sortedDirection, setSortedDirection,
		currentPage, setCurrentPage,
		itemOffset, setItemOffset,
		showFieldsFilter
	} = useDataSourceContext();
	const methods = useFormContext();
	const [state, dispatch] = React.useReducer<TDataGridState>(dataGridState, {
		timeStamp: Date.now(),
		isReady: false,
		//itemOffset: 0,
		//currentPage: 0,
		pageSize: props.options.pageSize || 50,
		columnsDef: props.columnsDef.map((columnDef: TTdsDataGridColumnDef) => {
			columnDef.sortable = columnDef.sortable == undefined ? true : columnDef.sortable;
			columnDef.sortDirection = columnDef.sortDirection == undefined ? "" : columnDef.sortDirection;
			columnDef.visible = columnDef.visible == undefined ? true : columnDef.visible;
			columnDef.grouping = columnDef.grouping == undefined ? false : columnDef.grouping;

			return columnDef;
		}),
		showFieldsFilter: false,
		//allFieldsFilter: filter,
		fieldsFilter: undefined,
		//sortedColumn: props.columnsDef.find((columnDef: TTdsDataGridColumnDef) => {
		//	return (columnDef.sortable && (columnDef.sortDirection !== "")) ? columnDef.sortable : undefined;
		//}),

		groupingInfo: undefined,
	});

	const handlePageClick = (newPage: number) => {
		const newOffset = (newPage * (props.options.pageSize)) % dataSource.length;

		setCurrentPage(newPage);
		setItemOffset(newOffset);
	}

	const handlePageSizeClick = (newSize: number) => {
		dispatch({ type: "set_page_size", value: newSize });
		setCurrentPage(0);
		setItemOffset(0);
	};

	const handleSortClick = (columnSort: TTdsDataGridColumnDef) => {
		columnSort.sortDirection = columnSort.sortDirection === "asc" ? "desc"
			: columnSort.sortDirection === "desc" ? "" : "asc";
		//}

		//dispatch({ type: "set_columns_def", columnsDef: state.columnsDef });
		setSortedColumn(columnSort);
		setSortedDirection(columnSort.sortDirection);
		//dispatch({ type: "set_sorted_column", columnIndex: indexColumn, direction: newColumnDef.sortDirection });
	}

	const handleGroupingClick = (columnDef: TTdsDataGridColumnDef | undefined) => {
		if (columnDef) {
			const groupingValues: Record<string, number> = dataSource.reduce((acc: Record<string, number>, item: any) => {
				if (acc[item[columnDef.name]]) {
					acc[item[columnDef.name]] += 1;
				} else {
					acc[item[columnDef.name]] = 1;
				}

				return acc;
			}, []);

			const indexColumn = state.columnsDef.indexOf(columnDef);
			dispatch({
				type: "set_grouping_info", grouping: {
					groupingCol: state.columnsDef[indexColumn],
					groupingValues: groupingValues,
					groupingFilter: []
				}
			})
		} else {
			dispatch({
				type: "set_grouping_info", grouping: undefined
			})
		}
	}

	if (props.options.topActions == undefined) {
		props.options.topActions = [];
	}
	if (props.options.bottomActions == undefined) {
		props.options.bottomActions = [];
	}
	if (props.options.grouping == undefined) {
		props.options.grouping = true;
	}
	if (props.options.filter == undefined) {
		props.options.filter = true;
	}
	if (props.options.sortable == undefined) {
		props.options.sortable = true;
	}
	if (props.options.pageSize == undefined) {
		props.options.pageSize = 50;
	}
	if (props.options.pageSizeOptions == undefined) {
		props.options.pageSizeOptions = [50, 100, 250, 500, 1000];
	}

	const buildRowHeader = (columnDefs: TTdsDataGridColumnDef[]): React.ReactElement[] => {
		let reactElements: React.ReactElement[] = [];
		let rowNumber: number = 0;

		while (rowNumber != -1) {
			let gridTemplate: string = "";

			columnDefs
				.filter(column => column.visible)
				.filter((column) => (column.rowGroup || 0) == rowNumber)
				.map((column, _index: number) => {
					gridTemplate += ` ${column.width || "1fr"} `;
				});

			reactElements.push(
				<VSCodeDataGridRow
					gridTemplateColumns={gridTemplate}
					row-type="header"
					id={`${props.id}_header_${rowNumber}`}
					key={`${props.id}_header_${rowNumber}`}
				>
					{
						columnDefs
							.filter(column => column.visible)
							.filter((column) => (column.rowGroup || 0) == rowNumber)
							.map((column, _index: number) => (
								<VSCodeDataGridCell
									cell-type="columnheader"
									grid-column={_index + 1}
									key={`${props.id}_header_column_${rowNumber}_${_index}`}
								>
									{column.label || column.name}
									{props.options.sortable && column.sortable &&
										<VSCodeButton
											appearance="icon"
											onClick={() => {
												handleSortClick(column);
											}}
										>
											{column.sortDirection == "asc" && <span className="codicon codicon-arrow-small-down"></span>}
											{column.sortDirection == "desc" && <span className="codicon codicon-arrow-small-up"></span>}
											{column.sortDirection == "" && <span className="codicon codicon-sort-precedence"></span>}
										</VSCodeButton>
									}
									{((props.options.grouping && column.grouping) || false) &&
										<VSCodeButton
											appearance="icon"
											aria-label={`Grouping by ${column.label || column.name}`}
											onClick={() => {
												handleGroupingClick(column);
											}}
										>
											<span className="codicon codicon-group-by-ref-type"></span>
										</VSCodeButton>
									}
								</VSCodeDataGridCell>
							))
					}
				</VSCodeDataGridRow >
			);

			rowNumber = rowNumber + 1;

			if (columnDefs.findIndex(column => (column.rowGroup || 0) == rowNumber) == -1) {
				rowNumber = -1;
			}
		}

		return reactElements;
	}

	if (!state.isReady) {
		dispatch({ type: "is_ready" });
	}

	if (keyContent !== state.timeStamp) {
		setKeyContent(state.timeStamp);
		// setDataSource(prepareDataSource(state.columnsDef, props._dataSource || [],
		// 	filter, state.fieldsFilter, state.groupingInfo,
		// 	state.sortedColumn));
	}

	React.useEffect(() => {
		console.log(">>>> useEffect")
		setDataSource(prepareDataSource(state.columnsDef, props._dataSource || [],
			filter, state.fieldsFilter, state.groupingInfo,
			sortedColumn));
	}, [filter, sortedColumn, sortedDirection, itemOffset, currentPage, showFieldsFilter]);

	return (
		<section className="tds-data-grid" id={`${props.id}`}>
			<div className="tds-data-grid-header">
				{(props.options.filter) && <FilterBlock
					actions={props.options.topActions}
				/>}
				{state.groupingInfo &&
					<GroupingBlock
						groupingInfo={state.groupingInfo}
						onFilterValues={(filterValues: string[]) => {
							if (filterValues) {
								dispatch({
									type: "set_grouping_info", grouping: {
										...state.groupingInfo,
										groupingFilter: filterValues
									}
								})

							} else {
								dispatch({
									type: "set_grouping_info", grouping: undefined
								});
							}
						}}
					/>}
			</div>

			<div className="tds-data-grid-content" key={`${props.id}_content`}>
				<VSCodeDataGrid
					id={`${props.id}_grid`}
					key={`${props.id}_grid`}
					generate-header="sticky"
				>
					{buildRowHeader(state.columnsDef)}

					{state.showFieldsFilter && <BuildRowFilter
						id={`${props.id}_grid_filter`}
						key={`${props.id}_grid_filter`}
						columnDefs={state.columnsDef}
						methods={methods}
						fieldsFilter={state.fieldsFilter || ""}
						onFilterFieldChanged={(filter: Record<string, string>) => {
							dispatch({ type: "set_fields_filter", filter: filter });
							handlePageClick(0);
						}}
						dataSource={dataSource}
					/>}

					{((dataSource == undefined) || (dataSource.length == 0)) ?
						<>No data to show.</>
						: <BuildRows
							key={`${props.id}`}
							id={`${props.id}`}
							columnsDef={state.columnsDef}
							rowSeparator={props.options.rowSeparator || false}
							itemOffset={itemOffset}
						/>
					}
				</VSCodeDataGrid>
			</div>

			<div className="tds-data-grid-footer">
				<TdsPaginator
					key={"paginator"}
					pageSize={state.pageSize}
					currentPage={currentPage}
					currentItem={itemOffset}
					totalItems={dataSource ? dataSource.length : 0}
					pageSizeOptions={props.options.pageSizeOptions}
					onPageChange={handlePageClick}
					onPageSizeChange={handlePageSizeClick}
				/>
				{props.options.bottomActions && <div className="tds-data-grid-actions">
					{props.options.bottomActions.map((action: TTdsDataGridAction) => {
						let propsField: any = {};
						let visible: string = "";

						if (typeof action.id === "string") {
							propsField["id"] = action.id;
						}

						propsField["type"] = action.type || "button";

						if (action.enabled !== undefined) {
							if (typeof action.enabled === "function") {
								propsField["disabled"] = !(action.enabled as Function)(false, true);
							} else {
								propsField["disabled"] = !action.enabled;
							}
						}

						if (action.appearance) {
							propsField["appearance"] = action.appearance;
						}

						if (action.onClick) {
							propsField["onClick"] = action.onClick;
						}

						if (action.visible !== undefined) {
							let isVisible: boolean = false;

							if (action.visible = typeof action.visible === "function") {
								isVisible = (Function)(action.visible)(false, true)
							} else {
								isVisible = action.visible;
							}

							visible = isVisible ? "" : "tds-hidden";
						}

						if (action.type == "link") {
							return (<VSCodeLink
								key={action.id}
								href={action.href}>{action.caption}
							</VSCodeLink>)
						} else if (action.type == "checkbox") {
							return (<VSCodeCheckbox
								key={action.id}
								className={`tds-button-button ${visible}`}
								{...propsField} >
								{action.caption}
							</VSCodeCheckbox>)
						} else {
							return (<VSCodeButton
								key={action.id}
								className={`tds-button-button ${visible}`}
								{...propsField} >
								{action.caption}
							</VSCodeButton>)
						}
					})}
				</div>
				}
			</div>
		</section >
	);
}
