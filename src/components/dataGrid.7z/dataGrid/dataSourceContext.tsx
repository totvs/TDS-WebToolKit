import * as React from "react";
import { TTdsDataGridColumnDef } from "./dataGrid.type";

interface DataSourceContextInterface {
    dataSource: any[];
    setDataSource: (dataSource: any[]) => void;
    setFilter: (filter: string) => void;
    filter: string;
    showFieldsFilter: boolean;
    setShowFieldsFilter: (show: boolean) => void;
    sortedColumn: TTdsDataGridColumnDef | undefined;
    setSortedColumn: (columnDef: TTdsDataGridColumnDef | undefined) => void
    sortedDirection: string;
    setSortedDirection: (direction: string) => void;
    currentPage: number;
    setCurrentPage: (page: number) => void;
    itemOffset: number;
    setItemOffset: (offset: number) => void;
}

const DataSourceContext = React.createContext<DataSourceContextInterface | undefined>(undefined);

export function useDataSourceContext() {
    const context = React.useContext(DataSourceContext);

    if (context === undefined) {
        throw new Error("useDataSourceContext must be used within a DataSourceProvider");
    }

    return context;
};

interface DataSourceProviderProps {
    children: React.ReactElement;
}

export function DataSourceProvider(props: DataSourceProviderProps) {
    const [dataSource, setDataSource] = React.useState<any[]>(undefined);
    const [filter, setFilter] = React.useState<string>(undefined);
    const [showFieldsFilter, setShowFieldsFilter] = React.useState<boolean>(false);
    const [sortedColumn, setSortedColumn] = React.useState<TTdsDataGridColumnDef | undefined>(undefined);
    const [sortedDirection, setSortedDirection] = React.useState<string>(undefined);
    const [currentPage, setCurrentPage] = React.useState<number>(0);
    const [itemOffset, setItemOffset] = React.useState<number>(0);

    return (
        <DataSourceContext.Provider value={{
            dataSource: dataSource,
            setDataSource: setDataSource,
            setFilter: setFilter,
            filter: filter,
            showFieldsFilter: showFieldsFilter,
            setShowFieldsFilter: setShowFieldsFilter,
            sortedColumn: sortedColumn,
            setSortedColumn: setSortedColumn,
            sortedDirection: sortedDirection,
            setSortedDirection: setSortedDirection,
            currentPage: currentPage,
            setCurrentPage: setCurrentPage,
            itemOffset: itemOffset,
            setItemOffset: setItemOffset

        }}>
            {props.children}
        </DataSourceContext.Provider>
    );
};

export default DataSourceContext;